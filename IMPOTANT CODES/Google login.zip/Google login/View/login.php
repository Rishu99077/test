<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="<?php echo $loginURL; ?>">
		<img src="<?php echo base_url(); ?>webroot/front/assets/images/google-logo.png">SIGN IN WITH GOOGLE
		</a>
</body>
</html>